module.exports.indexPage = (req,res) => {
    res.render('home/index')
}

module.exports.docsPage = (req,res) => {
    res.render('home/docs')
}